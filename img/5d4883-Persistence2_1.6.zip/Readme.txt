Thanks for downloading Persistence II by I'm Not MentaL.
If you like this mod, please like, rate, comment and subscribe, also Donate :)

Features:
This mod let you save your vehicle anywhere on the map and prevent your last vehicle vanish into thin air.
Work with any vehicles, including add-on vehicles.
- Support latest game version
- Can save trailer/towed vehicles

Compatible Mods:
- Nitro for all Vehicles
- Benny's Original Motor Works in SP
- MTL Flatbed Tow Truck v5.0 and above 

Requirements:
- Latest ScriptHookV
- Latest Community Script Hook V .NET
- Visual C++ Redistributable Packages x64 2015
- latest version of Microsoft .NET Framework according to SHVDN

Install:
1. Extract the files anywhere
2. Drag and Drop all the files into your GTAV Scripts Folder.
2a. If you are update from 1.5 or older version, please run 'PatchNitro.exe' to patch your existing files.
3. Profit.

Reload Script: Enter "reload persistence2" without quotes in the cheat console.

Changelog:
v1.6
- Update for Nitro for all Vehicles v1.3

v1.5
- Fixed Car Name included illegal characters failed to save properly.
- Increased distance detection so bigger vehicle can save.
- Metadata.dll lib updated to 1.2.101.0.

v1.4
- Added more Extras up to Extra15
- Prevent your last vehicle vanish into thin air.

v1.3
- Fixed vehicle spawn on top of each other (hopefully)

v1.2
- Fixed Performance drain problem from v1.1.

v1.1
- Fixed Custom Colors not showing up.
- Fixed Vehicles spawn double triple quadruple.
- Helicopter will spawn freezed position until you get close to it.

v1.0
- Fixed Crash while loading files.

v0.7 Beta
- Fixed compatible with Flatbed v5.0.

v0.6 Beta
- Critical bug fixed.

v0.4 Beta
- Fixed Livery not save.

v0.3 Beta
- Fixed Movement locked while playing animation.
- Hide Weapon when playing animation.
- Added Car Key prop while playing animation.

v0.2 Beta
- Indicators will flash when Lock/Unlock vehicles.

v0.1 Beta
- Fixed Towtruck always return HasTowing cause script crash when loading.
- Disabled Talk While Prompt for Lock/Unlock.

Decorator:
inm_persistence, Type Int, Returns value 0-3 (Michael, Franklin, Trevor, NPC) 

Credits: 
Decorator unlocker by Unknown Modder
ScriptHookV by Alexander Blade
ScriptHookVDotNet by Crosire
Spanish Translation by Gixer
German Translation by Pnda
Korean Translation by Mellanitomo Gen
Japanese Translation by ��ѩ��0w0
Portuguese & Italian Translation by Krazy!
Chinese Translation by Myself

I'm looking for these Translators: Russian, Polish, Mexican, Japanese, Italian & French.
Contact me on discord if interested, you will get my mods early like patreons.